#ifndef BTREE_H
    #define BTREE_H
    #include <stdio.h>
    #include <stdlib.h>
    #include "BTreeNode.h"
    #include "BTreeHeader.h"

    // Funções principais
    
#endif